/*
 ============================================================================
 Name        : ServerUDP.c
 Author      : Digirolamo Daniele
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */
/* Include header files for Windows and non-Windows platforms */
#if defined WIN32
#include <winsock.h>
#else
#include <string.h> // Include string manipulation functions
#include <unistd.h> // Include UNIX standard library functions
#include <sys/types.h> // Include system types definitions
#include <sys/socket.h> // Include socket definitions
#include <arpa/inet.h> // Include internet address handling definitions
#include <netinet/in.h> // Include internet definitions
#include <netdb.h> // Include network database definitions
#define closesocket close // Define 'closesocket' as 'close' for non-Windows platforms
#endif

/* Include standard input/output and standard library header files */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h> // Include character classification functions
#include "protocol.h" // Include custom protocol definition header file

/* Function to clear Winsock resources */
void clearwinsock() {
#if defined WIN32
	WSACleanup(); // Terminate Winsock DLL
#endif
}

/* Function to handle error messages */
void errorhandler(char *errorMessage) {
	perror(errorMessage); // Print error message to console
	exit(1); // Terminate program with error code 1
}

/* Function prototypes for arithmetic operations */
float add(int number1, int number2); // Declare function prototype for addition operation
float mult(int number1, int number2); // Declare function prototype for multiplication operation
float sub(int number1, int number2); // Declare function prototype for subtraction operation
float division(int number1, int number2); // Declare function prototype for division operation

/* Main function */
int main(int argc, char *argv[]) {

	/* Initialize Winsock for Windows platforms */
#if defined WIN32
	// Initialize Winsock
	WSADATA wsa_data;
	int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
	if (result != NO_ERROR) {
		printf("Error at WSAStartup()\n"); // Handle Winsock initialization failure
		return 0;
	}
#endif

	/* Create a UDP socket for client communication */
	int my_socket; // Client socket descriptor
	my_socket = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP); // Create socket using UDP protocol
	if (my_socket < 0) {
		errorhandler("socket creation failed.\n"); // Handle socket creation failure
		clearwinsock();
		return -1;
	}

	/* Set connection settings */
	struct sockaddr_in sad; // Address structure for server
	memset(&sad, 0, sizeof(sad)); // Initialize address structure to zeros
	sad.sin_family = AF_INET; // Address family for IPv4
	sad.sin_addr.s_addr = INADDR_ANY; // Server IP address
	sad.sin_port = htons(PROTO_PORT); // Server port

	/* Bind socket to the specified address and port */
	if (bind(my_socket, (struct sockaddr*) &sad, sizeof(sad)) < 0) {
		errorhandler("bind() failed.\n"); // Handle bind() error
		closesocket(my_socket);
		clearwinsock();
		return -1;
	}

	/* Announce to the client that the server is ready */
	printf("Ready to receive operations from clients...\n\n");

	/* Receive data from clients and perform arithmetic operations */
	struct sockaddr_in cad; // Structure for the client address
	int client_len;          // The size of the client address
	struct operation received_operation;
	char buffer[BUFFER_SIZE];

	while (1) {
		/* Receive data from client */
		client_len = sizeof(cad); // Set the size of the client address
		int bytes_received = recvfrom(my_socket, &received_operation,
				sizeof(received_operation), 0, (struct sockaddr*) &cad,
				&client_len);
		/* Handle recvfrom() failure */
		if (bytes_received <= 0) {
			errorhandler("recvfrom() failed or connection closed prematurely");
			continue; // Move to the next iteration
		}

		/* Display connection established message */
		printf("Connection established with %s:%d\n", inet_ntoa(cad.sin_addr),
				ntohs(cad.sin_port));

		/* Display client information and requested operation */
		printf("Request for operation '%c %d %d' from client %s, IP %s\n",
				received_operation.operation, received_operation.number1,
				received_operation.number2,
				gethostbyaddr((const char*) &cad.sin_addr, sizeof(cad.sin_addr),
				AF_INET)->h_name, inet_ntoa(cad.sin_addr));

		/* Perform the requested arithmetic operation */
		while (received_operation.operation != '=') {
			float result;

			switch (received_operation.operation) {
			case '+':
				result = add(received_operation.number1,
						received_operation.number2);
				break;
			case '-':
				result = sub(received_operation.number1,
						received_operation.number2);
				break;
			case 'x':
				result = mult(received_operation.number1,
						received_operation.number2);
				break;
			case '/':
				result = division(received_operation.number1,
						received_operation.number2);
				break;
			default:
				result = 0;
				break;
			}

			/* Send the result back to the client */
			int bytes_sent = sendto(my_socket, &result, sizeof(result), 0,
					(struct sockaddr*) &cad, sizeof(cad));

			if (bytes_sent <= 0) {
				errorhandler(
						"sendto() failed or connection closed prematurely");
				break; // Exit the loop if the sending fails
			}

			/* Receive the next operation from the client */
			client_len = sizeof(cad); // Set the size of the client address
			bytes_received = recvfrom(my_socket, &received_operation,
					sizeof(received_operation), 0, (struct sockaddr*) &cad,
					&client_len);

			if (bytes_received <= 0) {
				errorhandler(
						"recvfrom() failed or connection closed prematurely");
				break; // Exit the loop if the reception fails
			}

			/* Display client information and requested operation */
			printf("Request for operation '%c %d %d' from client %s, IP %s\n",
					received_operation.operation, received_operation.number1,
					received_operation.number2,
					gethostbyaddr((const char*) &cad.sin_addr,
							sizeof(cad.sin_addr),
							AF_INET)->h_name, inet_ntoa(cad.sin_addr));
		}
	}

	/* Close socket */
	closesocket(my_socket);
	clearwinsock();
	return 0;
}

/* Arithmetic operation functions */
float add(int number1, int number2) {
	return number1 + number2;
}

float mult(int number1, int number2) {
	return number1 * number2;
}

float sub(int number1, int number2) {
	return number1 - number2;
}

float division(int number1, int number2) {
	return (float) number1 / (float) number2;
}
