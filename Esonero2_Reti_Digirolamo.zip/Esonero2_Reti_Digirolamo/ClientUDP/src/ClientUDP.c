/*
 ============================================================================
 Name        : ClientUDP.c
 Author      : Digirolamo Daniele
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#if defined WIN32  // Check if the target platform is Windows
#include <winsock.h>  // Include Windows socket header file
#else  // Else, assume Unix-like platform
#include <string.h>  // Include string manipulation header file
#include <unistd.h>  // Include UNIX standard library header file
#include <sys/types.h>  // Include system types header file
#include <sys/socket.h>  // Include socket header file
#include <arpa/inet.h>  // Include internet address handling header file
#include <netinet/in.h>  // Include internet header file
#include <netdb.h>  // Include network database header file
#define closesocket close  // Define 'closesocket' as 'close' for non-Windows platforms
#endif

#include <stdio.h>  // Include standard input/output header file
#include <stdlib.h>  // Include standard library header file
#include "protocol.h"  // Include custom protocol definition header file

// Function to clear Winsock resources
void clearwinsock() {
#if defined WIN32
	WSACleanup();  // Terminate Winsock DLL
#endif
}

// Function to handle error messages
void errorhandler(char *errorMessage) {
	printf("%s", errorMessage);  // Print error message to console
	exit(1);  // Terminate program with error code 1
}

// Main function
int main(int argc, char *argv[]) {
#if defined WIN32
	// Initialize Winsock library
	WSADATA wsa_data;
	int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
	if (result != NO_ERROR) {
		printf("Error at WSAStartup()\n"); // Handle Winsock initialization error
		return 0;
	}
#endif

	// Server name and port
	char serverName[BUFFER_SIZE];  // Allocate buffer for server name
	strcpy(serverName, "srv.di.uniba.it");

	int port = PROTO_PORT;  // Set default port

	// Create a UDP socket for client communication
	int c_socket;  // Client socket descriptor
	c_socket = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP); // Create socket using UDP protocol
	if (c_socket < 0) {
		errorhandler("socket creation failed.\n"); // Handle socket creation failure
		closesocket(c_socket);
		clearwinsock();
		return -1;
	}

	// Obtain hostname and IP address information for the server
	struct hostent *host = gethostbyname(serverName); // Get hostname information
	if (host == NULL) {
		errorhandler("Error getting host");  // Handle host resolution failure
		clearwinsock();
		return EXIT_FAILURE;
	}

	// Set socket connection information
	struct sockaddr_in sad;  // Address structure for server
	memset(&sad, 0, sizeof(sad));  // Initialize address structure to zeros
	sad.sin_family = AF_INET;  // Address family for IPv4
	sad.sin_addr.s_addr = inet_addr("127.0.0.1"); // Set server IP address (localhost)
	sad.sin_port = htons(port);  // Set server port in network byte order

	// Receive response from the server
	int bytes_received;  // Number of bytes received

	printf("Server name: %s (IP: %s, port: %d)\n", serverName, // Display server information
			inet_ntoa(*(struct in_addr*) host->h_addr), port);

	// Receive operation and numbers from the user
	char operation[2];  // Buffer for operation character and '\0' terminator
	int number1, number2;  // Variables for the two numbers

	printf(
			"\tFirst enter the operation\n[ '+' for the Sum\n  '-' for the Difference\n"
					"  'x' for the Product\n  '/' for the Division ].\nThen the two integers number to operate."
					"\n\nWaiting for the inputs: ");
	scanf("%1s%d%d", operation, &number1, &number2); // Receive operation and numbers from user

	// Send operation and numbers to the server
	struct operation client_operation;  // Structure for operation and numbers
	client_operation.operation = operation[0];  // Set operation
	client_operation.number1 = number1;  // Set first number
	client_operation.number2 = number2;  // Set second number

	bytes_received = sendto(c_socket, &client_operation,
			sizeof(client_operation), 0, (struct sockaddr*) &sad, sizeof(sad)); // Send operation and numbers to server
	if (bytes_received <= 0) {
		errorhandler("sendto() failed or connection closed prematurely"); // Handle sendto failure
	}

	while (operation[0] != '=') {
		// Receive result from the server
		struct sockaddr_in server_address;  // Address structure for server
		int server_address_len = sizeof(server_address); // Length of server address structure

		float results;  // Variable for result

		bytes_received = recvfrom(c_socket, &results, sizeof(results), 0,
				(struct sockaddr*) &server_address, &server_address_len); // Receive result from server
		if (bytes_received <= 0) {
			errorhandler("recvfrom() failed or connection closed prematurely"); // Handle recvfrom failure
		}

		// Display result from the server
		printf("Received result from server %s, IP %s: %d %c %d = %.2f\n",
				gethostbyaddr((const char*) &server_address.sin_addr,
						sizeof(server_address.sin_addr), AF_INET)->h_name,
				inet_ntoa(server_address.sin_addr), number1, operation[0],
				number2, results);

		printf(
				"\tFirst enter the operation\n[ '+' for the Sum\n  '-' for the Difference\n"
						"  'x' for the Product\n  '/' for the Division ].\nThen the two integers number to operate."
						"\n\nWaiting for the inputs: ");
		// Receive operation and numbers from the user
		scanf("%1s%d%d", operation, &number1, &number2);

		// Send operation and numbers to the server
		struct operation client_operation;
		client_operation.operation = operation[0];
		client_operation.number1 = number1;
		client_operation.number2 = number2;

		bytes_received = sendto(c_socket, &client_operation,
				sizeof(client_operation), 0, (struct sockaddr*) &sad,
				sizeof(sad));
		if (bytes_received <= 0) {
			errorhandler("sendto() failed or connection closed prematurely");
		}
	}

	// Close the client socket
	closesocket(c_socket);
	clearwinsock();
	return 0;
}
