/*
 * Protocol.h
 *
 *  Created on: 19 dic 2023
 *      Author: Digirolamo Daniele
 */

#ifndef PROTOCOL_H_
#define PROTOCOL_H_

#define PROTO_PORT 56700
#define BUFFER_SIZE 255
#define NO_ERROR 0

struct operation {
    char operation;
    int number1;
    int number2;
};

#endif /* PROTOCOL_H_ */
