/*
 ============================================================================
 Name        : Client.c
 Author      : Digirolamo Daniele
 Version     : 1.0
 Copyright   : Your copyright notice
 Description : This is the Client who interact with the Server asking requests, and turn back the answer.
 ============================================================================
 */

#if defined WIN32
// Include the Winsock library for Windows
#include <winsock.h>
#else
// Include the necessary libraries for Unix-like systems
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
// Define closesocket as close for Unix-like systems
#define closesocket close
#endif

// Include the protocol header file
#include "protocol.h"

// Function to clean up Winsock resources
void clearwinsock() {
#if defined WIN32
	// Call WSACleanup() to clean up Winsock resources
	WSACleanup();
#endif
}

// Function to handle errors
void errorhandler(char *errorMessage) {
	// Print the error message
	printf("%s", errorMessage);
}

// Main function
int main(int argc, char *argv[]) {
#if defined WIN32
	// Initialize Winsock for Windows
	WSADATA wsa_data;
	int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
	if (result != NO_ERROR) {
		// Handle Winsock initialization error
		printf("Error at WSAStartup()\n");
		return 0;
	}
#endif

	// Create a socket for client-server communication
	int c_socket;
	// Initialize the socket for use
	c_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (c_socket < 0) {
		// Handle socket creation error
		errorhandler("Socket creation failed.\n");
		closesocket(c_socket);
		clearwinsock();
		return -1;
	}

	// Set the connection settings for the client socket
	struct sockaddr_in sad;
	memset(&sad, 0, sizeof(sad)); // Initialize the sockaddr_in structure
	sad.sin_family = AF_INET; // Set the address family to AF_INET (IPv4)
	sad.sin_addr.s_addr = inet_addr("127.0.0.1"); // Set the server IP address
	sad.sin_port = htons(PROTO_PORT); // Set the server port

	// Connect to the server
	if (connect(c_socket, (struct sockaddr*) &sad, sizeof(sad)) < 0) {
		// Handle connection error
		errorhandler("Failed to connect.\n");
		closesocket(c_socket);
		clearwinsock();
		return -1;
	}

	// Receive the echo message from the server
	char buffer[BUFFER_SIZE];
	int bytes_received = recv(c_socket, buffer, BUFFER_SIZE, 0);

	if (bytes_received <= 0) {
		// Handle receive error
		errorhandler("recv() failed or connection closed prematurely");
		closesocket(c_socket);
		clearwinsock();
		return -1;
	}

	int i = 0;

	while (buffer[i] != '\0') {
		// Print the received message character by character
		printf("%c", buffer[i]);
		i++;
	}

	puts(""); // Print a newline

	// Declare variables to store operation and numbers
	char operation[2];
	int number1, number2;

	// Prompt the user to enter an operation and two numbers
	printf("\tFirst enter the operation\n[ '+' for the Sum\n  '-' for the Difference\n  'x' for the Product\n  '/' for the Division ].\nThen the two integers number to operate.\n\nWaiting for the inputs: ");
	scanf("%1s%d%d", operation, &number1, &number2);

	// Continue the loop while the operation character is not '='
	while (operation[0] != '=') {
		// Create an operation structure to send to the server
		struct operation client_operation;
		client_operation.operation = operation[0]; // Set the operation character
		client_operation.number1 = number1; // Set the first number
		client_operation.number2 = number2; // Set the second number

		// Send the operation structure
		// Send the operation structure to the server
		bytes_received = send(c_socket, &client_operation,
				sizeof(client_operation), 0);

		if (bytes_received <= 0) {
			// Handle send error
			errorhandler("send() failed or connection closed prematurely");
		}

		// Receive the result from the server
		bytes_received = recv(c_socket, &result, sizeof(result), 0);

		if (bytes_received <= 0) {
			// Handle receive error
			errorhandler("recv() failed or connection closed prematurely");
		}

		// Print the result
		printf("Result: %d\n", result);

		// Prompt the user to enter an operation and two numbers
		printf("\tFirst enter the operation\n[ '+' for the Sum\n  '-' for the Difference\n  'x' for the Product\n  '/' for the Division ].\nThen the two integers number to operate.\n\nWaiting for the inputs: ");
		scanf("%1s%d%d", operation, &number1, &number2);
	}

	// Close the client socket
	closesocket(c_socket);
	clearwinsock();

	return 0;
}
