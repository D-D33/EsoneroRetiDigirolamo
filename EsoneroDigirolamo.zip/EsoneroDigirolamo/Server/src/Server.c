/*
 ============================================================================
 Name        : Server.c
 Author      : Digirolamo Daniele
 Version     : 1.0
 Copyright   : Your copyright notice
 Description : This is the server that allows connection and communication with clients. Furthermore, I carry out operations upon client request. 
 ============================================================================
 */

#if defined WIN32
// Include the Winsock library for Windows
#include <winsock.h>
#else
// Include the necessary libraries for Unix-like systems
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#endif

#if defined WIN32
// Include the Winsock library for Windows
#include <winsock.h>
#else
// Include the necessary libraries for Unix-like systems
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
// Define closesocket as close for Unix-like systems
#define closesocket close
#endif

// Include the protocol header file
#include "protocol.h"

// Function to clean up Winsock resources
void clearwinsock() {
#if defined WIN32
	// Call WSACleanup() to clean up Winsock resources
	WSACleanup();
#endif
}

// Function to handle errors
void errorhandler(char *errorMessage) {
	// Print the error message to standard error using perror()
	perror(errorMessage);
}

// Function to perform addition operation
int addition(int number1, int number2) {
	// Add the two numbers and return the result
	return number1 + number2;
}

// Function to perform subtraction operation
int subtraction(int number1, int number2) {
	// Subtract the second number from the first number and return the result
	return number1 - number2;
}

// Function to perform multiplication operation
int multiplication(int number1, int number2) {
	// Multiply the two numbers and return the result
	return number1 * number2;
}

// Function to perform division operation
int division(int number1, int number2) {
	// Divide the first number by the second number and return the result
	return number1 / number2;
}

// Main function
int main(int argc, char *argv[]) {
#if defined WIN32
	// Initialize Winsock for Windows
	WSADATA wsa_data;
	int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
	if (result != NO_ERROR) {
		// Handle Winsock initialization error
		printf("Error at WSAStartup()\n");
		return 0;
	}
#endif

	// Create a welcome socket to listen for incoming connections
	int my_socket;
	my_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (my_socket < 0) {
		// Handle socket creation error
		errorhandler("socket creation failed.\n");
		clearwinsock();
		return -1;
	}

	// Define an array to store client sockets
	int client_sockets[QLEN];
	int client_count = 0;

	// Set the connection settings for the welcome socket
	struct sockaddr_in sad;
	memset(&sad, 0, sizeof(sad));
	sad.sin_family = AF_INET; // Address family: IPv4
	sad.sin_addr.s_addr = INADDR_ANY; // Bind to any available address
	sad.sin_port = htons(PROTO_PORT); // Set the port number

	// Bind the welcome socket to the specified address and port
	if (bind(my_socket, (struct sockaddr*) &sad, sizeof(sad)) < 0) {
		// Handle bind error
		errorhandler("bind() failed.\n");
		closesocket(my_socket);
		clearwinsock();
		return -1;
	}

	// Listen for incoming connections with a maximum queue of QLEN
	if (listen(my_socket, QLEN) < 0) {
		// Handle listen error
		errorhandler("listen() failed.\n");
		closesocket(my_socket);
		clearwinsock();
		return -1;
	}

	// Continuously accept incoming connections
	while (1) {
		// Declare variables to store client
		// Declare variables to store client connection information
		struct sockaddr_in cad; // Structure for the client address
		printf("Waiting for a client to connect...\n\n");
		int c_socket;       // Socket descriptor for the client
		int client_len;          // The size of the client address

		// Accept a new connection
		client_len = sizeof(cad); // Set the size of the client address
		if ((c_socket = accept(my_socket, (struct sockaddr*) &cad, &client_len))
				< 0) {
			// Handle accept error
			errorhandler("accept() failed.\n");
			// Close connection
			closesocket(c_socket);
			clearwinsock();
			return 0;
		}

		// Add the new client socket to the array
		if (client_count < QLEN) {
			client_sockets[client_count++] = c_socket;
		} else {
			// Handle the case where the client queue is full
			// You can either close the new connection or send a message to the client
			printf("Queue full. Connection from %s closed.\n",
					inet_ntoa(cad.sin_addr));
			close(c_socket);
		}

		// Send a connection established message to the client
		char buffer[BUFFER_SIZE];
		printf("Connection established with %s:%d\n", inet_ntoa(cad.sin_addr),
				ntohs(cad.sin_port));
		sprintf(buffer, "Connection established with %s:%d\0",
				inet_ntoa(cad.sin_addr), ntohs(cad.sin_port));

		if (send(c_socket, buffer, strlen(buffer), 0) != strlen(buffer)) {
			errorhandler(
					"send() sent a different number of bytes than expected");
			closesocket(c_socket);
			clearwinsock();
			return -1;
		}

		// Receive the operation structure from the client
		char data[sizeof(struct operation)];
		int bytes_received;
		bytes_received = recv(c_socket, data, sizeof(data), 0);
		if (bytes_received <= 0) {
			errorhandler("recv() failed or connection closed prematurely");
		}

		// Process the received data
		struct operation *received_operation = (struct operation*) data;
		int result;

		while (received_operation->operation != '=') {
			// Get the operation type and the two numbers
			char operation = received_operation->operation;
			int number1 = received_operation->number1;
			int number2 = received_operation->number2;

			// Perform the operation
			switch (operation) {
			case '+':
				result = addition(number1, number2);
				break;
			case '-':
				result = subtraction(number1, number2);
				break;
			case 'x':
				result = multiplication(number1, number2);
				break;
			case '/':
				result = division(number1, number2);
				break;
			default:
				result = 0;
				break;
			}

			// Send the result back to the client
			bytes_received = send(c_socket, &result, sizeof(result), 0);
			if (bytes_received <= 0) {
				errorhandler("send() failed or connection closed prematurely");
				break;  // If the sending fails, exit from the loop
			}

			// Receive the next operation from the client
			bytes_received = recv(c_socket, data, sizeof(data), 0);
			if (bytes_received <= 0) {
				errorhandler("recv() failed or connection closed prematurely");
				break;  // If the reception fails, exit from the loop
			}

			// Process the received data
			received_operation = (struct operation*) data;
		}

		// Close the connection
		closesocket(c_socket);
	}

	// Close the welcome socket
	closesocket(my_socket);
	clearwinsock();

	// Return 0 to indicate success
	return 0;

} // main end
